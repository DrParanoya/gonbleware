package meteordevelopment.meteorclient.events.input;

import meteordevelopment.meteorclient.events.Cancellable;

public class KeyboardInputEvent extends Cancellable  {
    
}
