package meteordevelopment.meteorclient.events.entity.player;

public class PlayerJumpEvent {
    public static class Pre {
    
    }

    public static class Post {
        
    }
}
