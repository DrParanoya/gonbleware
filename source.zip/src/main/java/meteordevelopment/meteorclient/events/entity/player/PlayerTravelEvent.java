package meteordevelopment.meteorclient.events.entity.player;

import meteordevelopment.meteorclient.events.Cancellable;

public class PlayerTravelEvent {
    public static class Pre extends Cancellable {

    }

    public static class Post extends Cancellable {
        
    }
}
